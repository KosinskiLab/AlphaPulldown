#!/usr/bin/env python3
# coding: utf-8
"""
Feature generator for AlphaFold 2 and AlphaFold 3, supporting classic Hmmer, MMseqs2, and truemultimer modes.

"""

import json
import lzma
import os
import pickle
import re
import shutil
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
import numpy as np

from absl import logging, app, flags
from colabfold.utils import DEFAULT_API_SERVER

# AlphaFold2 imports
from alphafold.data import templates
from alphafold.data.pipeline import DataPipeline as AF2DataPipeline
from alphafold.data.tools import hmmsearch, hhsearch

# AlphaPulldown helpers
from alphapulldown.utils.create_custom_template_db import create_db
from alphapulldown.objects import MonomericObject
from alphapulldown.utils.file_handling import (
    iter_seqs,
    parse_csv_file,
    read_maybe_xz,
    resolve_af3_input,
)
from alphapulldown.utils.modelling_setup import create_uniprot_runner
from alphapulldown.utils.multimeric_template_utils import (
    extract_multimeric_template_features_for_single_chain,
)
from alphapulldown.utils import save_meta_data
from alphapulldown.utils.feature_metadata import embed_metadata_in_af3_json
from alphapulldown.utils.template_reuse import (
    msa_for_template_search,
    search_templates,
)

# Try to import AlphaFold3, but it's optional
AF3_IMPORT_ERROR = None
try:
    from alphafold3.data.pipeline import DataPipeline as AF3DataPipeline, DataPipelineConfig as AF3DataPipelineConfig
    from alphafold3.common import folding_input
except ImportError as exc:
    AF3DataPipeline = None
    AF3DataPipelineConfig = None
    folding_input = None
    AF3_IMPORT_ERROR = exc

# =================== Database Maps ===================
AF2_DATABASES = {
    "uniref90": "uniref90/uniref90.fasta",
    "uniref30": "uniref30/UniRef30_2023_02",
    "mgnify": "mgnify/mgy_clusters_2022_05.fa",
    "bfd": "bfd/bfd_metaclust_clu_complete_id30_c90_final_seq.sorted_opt",
    "small_bfd": "small_bfd/bfd-first_non_consensus_sequences.fasta",
    "pdb70": "pdb70/pdb70",
    "uniprot": "uniprot/uniprot.fasta",
    "pdb_seqres": "pdb_seqres/pdb_seqres.txt",
    "template_mmcif_dir": "pdb_mmcif/mmcif_files",
    "obsolete_pdbs": "pdb_mmcif/obsolete.dat",
}

AF3_DATABASES = {
    "uniref90": "uniref90_2022_05.fa",
    "mgnify": "mgy_clusters_2022_05.fa",
    "small_bfd": "bfd-first_non_consensus_sequences.fasta",
    "pdb_seqres": "pdb_seqres_2022_09_28.fasta",
    "template_mmcif_dir": "mmcif_files",
    "uniprot": "uniprot_all_2021_04.fa",
    "ntrna": "nt_rna_2023_02_23_clust_seq_id_90_cov_80_rep_seq.fasta",
    "rfam": "rfam_14_9_clust_seq_id_90_cov_80_rep_seq.fasta",
    "rna_central": "rnacentral_active_seq_id_90_cov_80_linclust.fasta",
}

AF2_FULL_DATABASE_FLAGS = {
    "uniref90_database_path": "uniref90",
    "uniref30_database_path": "uniref30",
    "mgnify_database_path": "mgnify",
    "bfd_database_path": "bfd",
    "small_bfd_database_path": "small_bfd",
    "pdb70_database_path": "pdb70",
    "uniprot_database_path": "uniprot",
    "pdb_seqres_database_path": "pdb_seqres",
    "template_mmcif_dir": "template_mmcif_dir",
    "obsolete_pdbs_path": "obsolete_pdbs",
}

AF2_REDUCED_DATABASE_FLAGS = {
    "uniref90_database_path": "uniref90",
    "mgnify_database_path": "mgnify",
    "small_bfd_database_path": "small_bfd",
    "uniprot_database_path": "uniprot",
    "pdb_seqres_database_path": "pdb_seqres",
    "template_mmcif_dir": "template_mmcif_dir",
    "obsolete_pdbs_path": "obsolete_pdbs",
}

AF3_DATABASE_FLAGS = {
    "uniref90_database_path": "uniref90",
    "mgnify_database_path": "mgnify",
    "small_bfd_database_path": "small_bfd",
    "uniprot_database_path": "uniprot",
    "pdb_seqres_database_path": "pdb_seqres",
    "template_mmcif_dir": "template_mmcif_dir",
    "ntrna_database_path": "ntrna",
    "rfam_database_path": "rfam",
    "rna_central_database_path": "rna_central",
}

DATABASE_PATH_FLAGS = (
    frozenset(AF2_FULL_DATABASE_FLAGS)
    | frozenset(AF2_REDUCED_DATABASE_FLAGS)
    | frozenset(AF3_DATABASE_FLAGS)
)

# =================== Flags ===================
flags.DEFINE_enum(
    'data_pipeline', 'alphafold2', ['alphafold2', 'alphafold3'],
    'Choose pipeline: alphafold2 or alphafold3'
)
flags.DEFINE_list('fasta_paths', None, 'Paths to FASTA files, each containing a prediction target.')
flags.DEFINE_string('data_dir', None, 'Path to directory of supporting data.')
flags.DEFINE_string('output_dir', None, 'Path to output directory.')
flags.DEFINE_string('jackhmmer_binary_path', shutil.which('jackhmmer'), '')
flags.DEFINE_string('hhblits_binary_path', shutil.which('hhblits'), '')
flags.DEFINE_string('hhsearch_binary_path', shutil.which('hhsearch'), '')
flags.DEFINE_string('hmmsearch_binary_path', shutil.which('hmmsearch'), '')
flags.DEFINE_string('hmmbuild_binary_path', shutil.which('hmmbuild'), '')
flags.DEFINE_string('nhmmer_binary_path', shutil.which('nhmmer'), '')
flags.DEFINE_string('hmmalign_binary_path', shutil.which('hmmalign'), '')
flags.DEFINE_string('kalign_binary_path', shutil.which('kalign'), '')
flags.DEFINE_string('uniref90_database_path', None, '')
flags.DEFINE_string('mgnify_database_path', None, '')
flags.DEFINE_string('bfd_database_path', None, '')
flags.DEFINE_string('small_bfd_database_path', None, '')
flags.DEFINE_string('uniref30_database_path', None, '')
flags.DEFINE_string('uniprot_database_path', None, '')
flags.DEFINE_string('pdb70_database_path', None, '')
flags.DEFINE_string('pdb_seqres_database_path', None, '')
flags.DEFINE_string('ntrna_database_path', None, '')
flags.DEFINE_string('rfam_database_path', None, '')
flags.DEFINE_string('rna_central_database_path', None, '')
flags.DEFINE_string('template_mmcif_dir', None, '')
flags.DEFINE_string('max_template_date', None, 'Max template release date.')
flags.DEFINE_string('obsolete_pdbs_path', None, '')
flags.DEFINE_enum('db_preset', 'full_dbs', ['full_dbs', 'reduced_dbs'], '')
flags.DEFINE_boolean('use_precomputed_msas', False, '')
flags.DEFINE_boolean('re_search_templates_mmseqs2', False, '')
flags.DEFINE_bool("use_mmseqs2", False, "")
flags.DEFINE_bool("save_msa_files", False, "")
flags.DEFINE_bool("skip_msa", False, "")
flags.DEFINE_bool("skip_existing", False, "")
flags.DEFINE_string("new_uniclust_dir", None, "")
flags.DEFINE_integer("seq_index", None, "")
flags.DEFINE_boolean("use_hhsearch", False, "")
flags.DEFINE_boolean("compress_features", False, "")
flags.DEFINE_boolean(
    "keep_msas", False,
    "Update existing features in --output_dir in place: keep their MSAs and "
    "re-run only the template search. Use this when the template database or "
    "--max_template_date has changed but the alignments are still valid; it "
    "costs a template search instead of a full MSA run. Features that do not "
    "already exist are generated normally.",
)
flags.DEFINE_string("path_to_mmt", None, "")
flags.DEFINE_string("description_file", None, "")
flags.DEFINE_float("threshold_clashes", 1000, "")
flags.DEFINE_float("hb_allowance", 0.4, "")
flags.DEFINE_float("plddt_threshold", 0, "")
flags.DEFINE_boolean("multiple_mmts", False, "")

FLAGS = flags.FLAGS

AF3_DNA_BASES = frozenset("ACGTN")
AF3_RNA_BASES = frozenset("ACGUN")
AF3_PROTEIN_RESIDUES = frozenset("ACDEFGHIKLMNPQRSTVWYX")
AF3_PROTEIN_ONLY_RESIDUES = AF3_PROTEIN_RESIDUES - (AF3_DNA_BASES | {"U"})

AF3_PROTEIN_MSA_DATABASE_FLAGS = frozenset({
    "uniref90_database_path",
    "mgnify_database_path",
    "small_bfd_database_path",
    "uniprot_database_path",
})
AF3_TEMPLATE_DATABASE_FLAGS = frozenset({
    "pdb_seqres_database_path",
    "template_mmcif_dir",
})
AF3_RNA_DATABASE_FLAGS = frozenset({
    "ntrna_database_path",
    "rfam_database_path",
    "rna_central_database_path",
})
AF3_PROTEIN_MSA_BINARY_FLAGS = frozenset({"jackhmmer_binary_path"})
AF3_TEMPLATE_BINARY_FLAGS = frozenset({
    "hmmbuild_binary_path",
    "hmmsearch_binary_path",
})
AF3_RNA_BINARY_FLAGS = frozenset({
    "hmmalign_binary_path",
    "hmmbuild_binary_path",
    "nhmmer_binary_path",
})

# =================== Helper Functions ===================

def validate_data_pipeline_flags():
    """Validate flag combinations that differ between AF2 and AF3."""
    if FLAGS.data_pipeline == "alphafold3" and FLAGS.use_mmseqs2:
        raise ValueError(
            "AlphaFold3 does not support --use_mmseqs2. "
            "Please provide local databases via --data_dir."
        )
    if FLAGS.keep_msas and FLAGS.use_mmseqs2:
        # MMseqs2 obtains MSAs and templates together from the remote server;
        # there is no separable template search to re-run against a local
        # database, so the combination cannot do what the flag promises.
        raise ValueError(
            "--keep_msas cannot be combined with --use_mmseqs2: the MMseqs2 "
            "path fetches MSAs and templates together and has no standalone "
            "template search to re-run."
        )
    if FLAGS.keep_msas and FLAGS.skip_msa:
        raise ValueError(
            "--keep_msas cannot be combined with --skip_msa: there are no MSAs "
            "to keep when MSA generation is skipped."
        )

def get_database_path(key):
    """Return the absolute path for a given database key, depending on pipeline."""
    validate_data_pipeline_flags()

    # When using MMseqs2 remotely (current implementation), data_dir is not required
    # Note: Local MMseqs2 would require data_dir, but current implementation uses remote
    if FLAGS.use_mmseqs2 and not FLAGS.data_dir:
        return None
    
    # For non-MMseqs2 or when data_dir is provided, data_dir must be valid
    if not FLAGS.data_dir:
        raise ValueError("data_dir is required when not using MMseqs2")
    
    db_map = AF3_DATABASES if FLAGS.data_pipeline == 'alphafold3' else AF2_DATABASES
    try:
        default_subpath = db_map[key]
    except KeyError as exc:
        raise KeyError(
            f"Database '{key}' is not configured for the {FLAGS.data_pipeline} pipeline"
        ) from exc
    return os.path.join(FLAGS.data_dir, default_subpath)

def create_arguments(local_custom_template_db=None):
    """Set the database path flags relevant to the selected AlphaFold version.
    Optionally override template paths with a local custom template DB."""
    validate_data_pipeline_flags()

    required_database_flags = get_required_database_flags()

    # When using MMseqs2 (current implementation uses remote servers), database paths are not needed
    # Note: Current MMseqs2 implementation uses remote servers via DEFAULT_API_SERVER
    # For local MMseqs2, data_dir would be required and database paths would be set
    if FLAGS.use_mmseqs2:
        # When using MMseqs2, we don't need local database paths regardless of data_dir
        for flag_name in DATABASE_PATH_FLAGS:
            setattr(FLAGS, flag_name, None)
    else:
        for flag_name, db_key in required_database_flags.items():
            setattr(FLAGS, flag_name, getattr(FLAGS, flag_name) or get_database_path(db_key))
        for flag_name in DATABASE_PATH_FLAGS - frozenset(required_database_flags):
            setattr(FLAGS, flag_name, None)
    
    if local_custom_template_db and FLAGS.data_pipeline != 'alphafold3':
        FLAGS.pdb_seqres_database_path = os.path.join(local_custom_template_db, "pdb_seqres.txt")
        FLAGS.template_mmcif_dir = os.path.join(local_custom_template_db, "pdb_mmcif", "mmcif_files")
        FLAGS.obsolete_pdbs_path = os.path.join(local_custom_template_db, "pdb_mmcif", "obsolete.dat")


def get_required_database_flags():
    """Return the database flags required by the selected pipeline and preset."""
    if FLAGS.data_pipeline == "alphafold3":
        return AF3_DATABASE_FLAGS

    if FLAGS.db_preset == "reduced_dbs":
        required_flags = dict(AF2_REDUCED_DATABASE_FLAGS)
        if FLAGS.use_hhsearch:
            required_flags["pdb70_database_path"] = "pdb70"
        return required_flags

    return AF2_FULL_DATABASE_FLAGS

def check_template_date():
    """Check if the max_template_date is provided."""
    if not FLAGS.max_template_date:
        logging.error("You have not provided a max_template_date. Please specify a date and run again.")
        sys.exit(1)

def get_af3_chain_kind(description, sequence):
    """Infer an AF3 chain kind, requiring an explicit hint for ambiguous alphabets."""
    residues = set(sequence.upper())
    if not residues:
        raise ValueError("Sequence is empty.")

    invalid_residues = residues - (AF3_PROTEIN_RESIDUES | {"U"})
    if invalid_residues:
        invalid_list = ", ".join(sorted(invalid_residues))
        raise ValueError(f"Invalid sequence residues: {invalid_list}")

    if residues <= AF3_RNA_BASES and "U" in residues:
        return "rna"
    if residues & AF3_PROTEIN_ONLY_RESIDUES:
        return "protein"

    description_tokens = {
        token for token in re.split(r"[^A-Za-z0-9]+", description.lower()) if token
    }
    if "dna" in description_tokens:
        return "dna"
    if "rna" in description_tokens:
        return "rna"
    if {"protein", "prot", "peptide"} & description_tokens:
        return "protein"

    raise ValueError(
        "Ambiguous sequence alphabet. Add 'DNA', 'RNA', or 'protein' to "
        f"the FASTA description for '{description}' to disambiguate."
    )

def create_af3_chain(sequence, description, chain_id):
    """Construct an AF3 chain object for the provided sequence."""
    chain_kind = get_af3_chain_kind(description, sequence)
    query_only_a3m = f">query\n{sequence}\n" if FLAGS.skip_msa else None
    if chain_kind == "dna":
        return folding_input.DnaChain(
            sequence=sequence,
            id=chain_id,
            modifications=[],
            description=description,
        )
    if chain_kind == "rna":
        kwargs = {
            "sequence": sequence,
            "id": chain_id,
            "modifications": [],
            "description": description,
        }
        if FLAGS.skip_msa:
            kwargs["unpaired_msa"] = query_only_a3m
        return folding_input.RnaChain(**kwargs)

    kwargs = {
        "sequence": sequence,
        "id": chain_id,
        "ptms": [],
        "description": description,
    }
    if FLAGS.skip_msa:
        kwargs.update(
            {
                "paired_msa": "",
                "unpaired_msa": query_only_a3m,
                "templates": None,
            }
        )
    return folding_input.ProteinChain(**kwargs)


def filter_af3_metadata_flags(flag_dict, chain_kinds, *, skip_msa):
    """Keep only resources used by AF3 for the requested molecule types."""
    chain_kinds = frozenset(chain_kinds)
    unknown_kinds = chain_kinds - {"protein", "rna", "dna"}
    if unknown_kinds:
        raise ValueError(
            "Unsupported AF3 chain kinds for metadata: "
            + ", ".join(sorted(unknown_kinds))
        )

    database_flags = set()
    binary_flags = set()
    if "protein" in chain_kinds:
        database_flags.update(AF3_TEMPLATE_DATABASE_FLAGS)
        binary_flags.update(AF3_TEMPLATE_BINARY_FLAGS)
        if not skip_msa:
            database_flags.update(AF3_PROTEIN_MSA_DATABASE_FLAGS)
            binary_flags.update(AF3_PROTEIN_MSA_BINARY_FLAGS)
    if "rna" in chain_kinds and not skip_msa:
        database_flags.update(AF3_RNA_DATABASE_FLAGS)
        binary_flags.update(AF3_RNA_BINARY_FLAGS)

    filtered = dict(flag_dict)
    for flag_name in DATABASE_PATH_FLAGS - database_flags:
        if flag_name in filtered:
            filtered[flag_name] = None
    for flag_name in filtered:
        if flag_name.endswith("_binary_path") and flag_name not in binary_flags:
            filtered[flag_name] = None
    return filtered


def get_af3_feature_metadata(chain_kinds, *, skip_msa):
    """Collect provenance for resources the AF3 pipeline actually uses."""
    metadata_flags = filter_af3_metadata_flags(
        FLAGS.flag_values_dict(), chain_kinds, skip_msa=skip_msa
    )
    metadata = save_meta_data.get_meta_dict(metadata_flags)
    try:
        from alphafold3 import version as af3_version

        metadata.setdefault("software", {}).setdefault("AlphaFold", {})[
            "version"
        ] = af3_version.__version__
    except (ImportError, AttributeError):
        logging.warning("Could not determine the AlphaFold 3 version for metadata")
    return metadata

# =================== AlphaFold 2 Feature Creation ===================

def _create_af2_template_stack():
    """Create the AF2 template searcher and featurizer."""
    if FLAGS.use_hhsearch:
        template_searcher = hhsearch.HHSearch(
            binary_path=FLAGS.hhsearch_binary_path, databases=[FLAGS.pdb70_database_path]
        )
        template_featuriser = templates.HhsearchHitFeaturizer(
            mmcif_dir=FLAGS.template_mmcif_dir, max_template_date=FLAGS.max_template_date,
            max_hits=20, kalign_binary_path=FLAGS.kalign_binary_path,
            release_dates_path=None, obsolete_pdbs_path=FLAGS.obsolete_pdbs_path
        )
    else:
        template_featuriser = templates.HmmsearchHitFeaturizer(
            mmcif_dir=FLAGS.template_mmcif_dir, max_template_date=FLAGS.max_template_date,
            max_hits=20, kalign_binary_path=FLAGS.kalign_binary_path,
            obsolete_pdbs_path=FLAGS.obsolete_pdbs_path, release_dates_path=None
        )
        template_searcher = hmmsearch.Hmmsearch(
            binary_path=FLAGS.hmmsearch_binary_path,
            hmmbuild_binary_path=FLAGS.hmmbuild_binary_path,
            database_path=FLAGS.pdb_seqres_database_path
        )
    return template_searcher, template_featuriser


def create_pipeline_af2():
    """Create and configure the AlphaFold2 data pipeline."""
    use_small_bfd = FLAGS.db_preset == "reduced_dbs"
    
    # When using MMseqs2, we don't need template search/featurization
    if FLAGS.use_mmseqs2:
        template_searcher = None
        template_featuriser = None
    else:
        template_searcher, template_featuriser = _create_af2_template_stack()

    if FLAGS.skip_msa:
        return SimpleNamespace(
            template_searcher=template_searcher,
            template_featurizer=template_featuriser,
        )
    
    return AF2DataPipeline(
        jackhmmer_binary_path=FLAGS.jackhmmer_binary_path,
        hhblits_binary_path=FLAGS.hhblits_binary_path,
        uniref90_database_path=FLAGS.uniref90_database_path,
        mgnify_database_path=FLAGS.mgnify_database_path,
        bfd_database_path=FLAGS.bfd_database_path,
        uniref30_database_path=FLAGS.uniref30_database_path,
        small_bfd_database_path=FLAGS.small_bfd_database_path,
        use_small_bfd=use_small_bfd,
        use_precomputed_msas=FLAGS.use_precomputed_msas,
        template_searcher=template_searcher,
        template_featurizer=template_featuriser
    )

def create_individual_features():
    """Generate AlphaFold2 features for each monomer sequence."""
    create_arguments()
    
    # When using MMseqs2, we don't need a pipeline or uniprot_runner
    if FLAGS.use_mmseqs2:
        pipeline = None
        uniprot_runner = None
    else:
        pipeline = create_pipeline_af2()
        if FLAGS.skip_msa:
            uniprot_runner = None
        else:
            uniprot_runner = create_uniprot_runner(
                FLAGS.jackhmmer_binary_path, FLAGS.uniprot_database_path
            )
    
    for seq_idx, (seq, desc) in enumerate(iter_seqs(FLAGS.fasta_paths), 1):
        if FLAGS.seq_index is None or seq_idx == FLAGS.seq_index:
            # --keep_msas updates existing features in place. When none exist
            # yet there is nothing to keep, so fall through and generate them.
            if FLAGS.keep_msas and _update_templates_keeping_msas(
                desc, seq, pipeline
            ):
                continue
            monomer = MonomericObject(desc, seq)
            monomer.uniprot_runner = uniprot_runner
            create_and_save_monomer_objects(monomer, pipeline)

def _feature_pickle_path(description, *, compress):
    suffix = ".pkl.xz" if compress else ".pkl"
    return Path(FLAGS.output_dir) / f"{description}{suffix}"


def _metadata_output_path(description):
    return Path(FLAGS.output_dir) / (
        f"{description}_feature_metadata_{datetime.now().date()}.json"
    )


def _should_skip_monomer_output(description):
    pickle_path = _feature_pickle_path(description, compress=FLAGS.compress_features)
    if FLAGS.skip_existing and pickle_path.exists():
        logging.info(f"Feature file for {description} already exists. Skipping...")
        return True
    return False


def _persist_monomer_outputs(monomer):
    meta_dict = save_meta_data.get_meta_dict(FLAGS.flag_values_dict())
    metadata_output_path = _metadata_output_path(monomer.description)
    if FLAGS.compress_features:
        with lzma.open(str(metadata_output_path) + ".xz", "wt") as meta_data_outfile:
            json.dump(meta_dict, meta_data_outfile)
        with lzma.open(_feature_pickle_path(monomer.description, compress=True), "wb") as pickle_file:
            pickle.dump(monomer, pickle_file)
    else:
        with open(metadata_output_path, "w") as meta_data_outfile:
            json.dump(meta_dict, meta_data_outfile)
        with open(_feature_pickle_path(monomer.description, compress=False), "wb") as pickle_file:
            pickle.dump(monomer, pickle_file)


def _load_existing_monomer_from_output_dir(description):
    for suffix in (".pkl", ".pkl.xz"):
        pickle_path = Path(FLAGS.output_dir) / f"{description}{suffix}"
        if not pickle_path.exists():
            continue
        if suffix == ".pkl.xz":
            with lzma.open(pickle_path, "rb") as handle:
                return pickle.load(handle)
        with open(pickle_path, "rb") as handle:
            return pickle.load(handle)
    return None


def _infer_truemultimer_source_name(protein, template_paths, chains):
    if len(template_paths) != 1 or len(chains) != 1:
        return protein
    template_name = Path(template_paths[0]).name
    suffix = f".{template_name}.{chains[0]}"
    if protein.endswith(suffix):
        return protein[: -len(suffix)]
    return protein


def _replace_template_features(monomer, template_features):
    monomer.feature_dict = {
        key: value
        for key, value in monomer.feature_dict.items()
        if not key.startswith("template_")
    }
    monomer.feature_dict.update(template_features)

    template_count = 0
    if "template_aatype" in monomer.feature_dict:
        template_count = int(monomer.feature_dict["template_aatype"].shape[0])
    elif "template_sequence" in monomer.feature_dict:
        template_count = len(monomer.feature_dict["template_sequence"])
    template_count = max(template_count, 1)

    if "template_sum_probs" in monomer.feature_dict:
        monomer.feature_dict["template_sum_probs"] = np.asarray(
            monomer.feature_dict["template_sum_probs"], dtype=np.float32
        )
    else:
        monomer.feature_dict["template_sum_probs"] = np.zeros(
            template_count, dtype=np.float32
        )
    if "template_confidence_scores" not in monomer.feature_dict:
        monomer.feature_dict["template_confidence_scores"] = np.ones(
            (template_count, len(monomer.sequence)), dtype=np.float32
        )
    if "template_release_date" not in monomer.feature_dict:
        monomer.feature_dict["template_release_date"] = np.array(
            ["none"] * template_count, dtype=object
        )


def _existing_monomer_for_update(description, sequence):
    """Load existing features for in-place update, or None to regenerate.

    Shared by the two modes that rewrite an existing monomer's templates
    (TrueMultimer reuse and ``--keep_msas``). A sequence mismatch means the
    stored features describe a different protein under the same name, so they
    must not be updated in place.
    """
    monomer = _load_existing_monomer_from_output_dir(description)
    if monomer is None:
        return None
    stored = getattr(monomer, "sequence", None)
    if stored != sequence:
        logging.warning(
            "Existing features for %s hold sequence %s but the input FASTA has "
            "%s; regenerating from scratch instead of updating templates.",
            description, stored, sequence,
        )
        return None
    return monomer


def _update_templates_keeping_msas(description, sequence, pipeline):
    """Re-run template search for one existing monomer, keeping its MSAs.

    Returns True when the stored features were updated, False when there is
    nothing to update and the caller should generate features normally.
    """
    monomer = _existing_monomer_for_update(description, sequence)
    if monomer is None:
        return False

    template_searcher = getattr(pipeline, "template_searcher", None)
    template_featurizer = getattr(pipeline, "template_featurizer", None)
    if template_searcher is None or template_featurizer is None:
        raise RuntimeError(
            "--keep_msas needs a template searcher and featurizer, but the "
            "pipeline provides none. Template search cannot be skipped in this "
            "mode, since re-running it is the entire point."
        )

    msa_output_dir = Path(FLAGS.output_dir) / description
    msa = msa_for_template_search(monomer, msa_output_dir)
    template_features = search_templates(
        template_searcher,
        template_featurizer,
        query_sequence=sequence,
        stockholm_msa=msa.stockholm,
        msa_output_dir=msa_output_dir,
    )
    _replace_template_features(monomer, template_features)
    # Keep the provenance with the features: which alignment drove the search
    # decides whether the hits reproduce a fresh run (see template_reuse).
    monomer.template_msa_source = msa.source
    _persist_monomer_outputs(monomer)
    logging.info(
        "Updated templates for %s from %s (MSAs kept, %d template(s)).",
        description, msa.source,
        int(np.asarray(template_features.get("template_domain_names", [])).shape[0])
        if "template_domain_names" in template_features else 0,
    )
    return True


def _reuse_truemultimer_monomer_features(feat):
    if FLAGS.use_mmseqs2 or len(feat["templates"]) != 1 or len(feat["chains"]) != 1:
        return None

    source_name = _infer_truemultimer_source_name(
        feat["protein"], feat["templates"], feat["chains"]
    )
    # Shares the load-and-validate step with --keep_msas: both modes rewrite an
    # existing monomer's templates and must refuse when the stored features
    # describe a different sequence.
    monomer = _existing_monomer_for_update(source_name, feat["sequence"])
    if monomer is None:
        return None
    cached_skip_msa = getattr(monomer, "skip_msa", False)
    if FLAGS.skip_msa != cached_skip_msa:
        requested_mode = "--skip_msa" if FLAGS.skip_msa else "full-MSA"
        cached_mode = "--skip_msa" if cached_skip_msa else "full-MSA"
        logging.info(
            "Existing monomer features for %s were generated in %s mode, but the "
            "current TrueMultimer entry requested %s mode. Recomputing features.",
            source_name,
            cached_mode,
            requested_mode,
        )
        return None

    template_path = feat["templates"][0]
    chain_id = feat["chains"][0]
    template_result = extract_multimeric_template_features_for_single_chain(
        query_seq=monomer.sequence,
        pdb_id=Path(template_path).stem,
        chain_id=chain_id,
        mmcif_file=template_path,
        threshold_clashes=FLAGS.threshold_clashes,
        hb_allowance=FLAGS.hb_allowance,
        plddt_threshold=FLAGS.plddt_threshold,
    )
    if template_result is None or template_result.features is None:
        raise RuntimeError(
            f"Failed to extract template features from {template_path} chain {chain_id}."
        )

    monomer.description = feat["protein"]
    monomer.sequence = feat["sequence"]
    monomer.uniprot_runner = None
    _replace_template_features(monomer, template_result.features)
    logging.info(
        "Reused existing monomer features from %s for TrueMultimer target %s.",
        source_name,
        feat["protein"],
    )
    return monomer


def create_and_save_monomer_objects(monomer, pipeline, custom_template_path=None):
    """Save a MonomericObject after feature creation (pickled, optionally compressed)."""
    # Ensure output directory exists
    os.makedirs(FLAGS.output_dir, exist_ok=True)

    if _should_skip_monomer_output(monomer.description):
        return
    monomer.skip_msa = FLAGS.skip_msa
    if FLAGS.use_mmseqs2:
        monomer.make_mmseq_features(
            DEFAULT_API_SERVER=DEFAULT_API_SERVER,
            output_dir=FLAGS.output_dir,
            use_precomputed_msa=FLAGS.use_precomputed_msas,
            use_templates=FLAGS.re_search_templates_mmseqs2 or custom_template_path is not None,
            custom_template_path=custom_template_path,
            skip_msa=FLAGS.skip_msa,
        )
    else:
        monomer.make_features(
            pipeline=pipeline, output_dir=FLAGS.output_dir,
            use_precomputed_msa=FLAGS.use_precomputed_msas,
            save_msa=FLAGS.save_msa_files,
            skip_msa=FLAGS.skip_msa,
        )
    _persist_monomer_outputs(monomer)

def create_individual_features_truemultimer():
    """Generate features in TrueMultimer mode, one set per entry in the description CSV."""
    feats = parse_csv_file(
        FLAGS.description_file, FLAGS.fasta_paths, FLAGS.path_to_mmt, FLAGS.multiple_mmts
    )
    for idx, feat in enumerate(feats, 1):
        if FLAGS.seq_index is None or idx == FLAGS.seq_index:
            process_multimeric_features(feat, idx)

def process_multimeric_features(feat, idx):
    """Process a multimeric feature from a parsed CSV entry."""
    for temp_path in feat["templates"]:
        if not os.path.isfile(temp_path):
            raise FileNotFoundError(f"Template file {temp_path} does not exist.")
    reused_monomer = _reuse_truemultimer_monomer_features(feat)
    if reused_monomer is not None:
        if _should_skip_monomer_output(reused_monomer.description):
            return
        _persist_monomer_outputs(reused_monomer)
        return
    protein, chains, template_paths = feat["protein"], feat["chains"], feat["templates"]
    with tempfile.TemporaryDirectory() as temp_dir:
        local_path_to_custom_db = create_custom_db(temp_dir, protein, template_paths, chains)
        create_arguments(local_path_to_custom_db)
        
        # When using MMseqs2, we don't need a pipeline or uniprot_runner
        if FLAGS.use_mmseqs2:
            pipeline = None
            uniprot_runner = None
        else:
            pipeline = create_pipeline_af2()
            if FLAGS.skip_msa:
                uniprot_runner = None
            else:
                uniprot_runner = create_uniprot_runner(
                    FLAGS.jackhmmer_binary_path, FLAGS.uniprot_database_path
                )
        
        monomer = MonomericObject(protein, feat['sequence'])
        monomer.uniprot_runner = uniprot_runner
        custom_template_path = str(Path(local_path_to_custom_db) / "templates")
        create_and_save_monomer_objects(
            monomer,
            pipeline,
            custom_template_path=custom_template_path if FLAGS.use_mmseqs2 else None,
        )

def create_custom_db(temp_dir, protein, template_paths, chains):
    """Create a local custom template DB for TrueMultimer/AF2."""
    local_path_to_custom_template_db = Path(temp_dir) / "custom_template_db" / protein
    create_db(
        local_path_to_custom_template_db, template_paths, chains,
        FLAGS.threshold_clashes, FLAGS.hb_allowance, FLAGS.plddt_threshold
    )
    return local_path_to_custom_template_db

# =================== AlphaFold 3 Feature Creation ===================

def create_pipeline_af3():
    """Create the AlphaFold3 pipeline. Raises if AF3 not available."""
    validate_data_pipeline_flags()

    if AF3DataPipeline is None or AF3DataPipelineConfig is None:
        raise ImportError(
            "AlphaFold3 is not installed correctly. "
            "Install AlphaPulldown with 'pip install -e \".[alphafold3,test]\"', "
            "make sure the build environment provides SQLite, then build the "
            "vendored package with 'pip install -r alphafold3/dev-requirements.txt', "
            "'pip install --no-deps -e ./alphafold3', and 'build_data'."
        ) from AF3_IMPORT_ERROR
    
    # Convert max_template_date string to datetime.date object
    import datetime
    max_template_date = datetime.date.fromisoformat(FLAGS.max_template_date)
    def _ovr(attr, key):
        v = getattr(FLAGS, attr, None)
        return v or get_database_path(key)
    
    config = AF3DataPipelineConfig(
        jackhmmer_binary_path=FLAGS.jackhmmer_binary_path,
        nhmmer_binary_path=FLAGS.nhmmer_binary_path,
        hmmalign_binary_path=FLAGS.hmmalign_binary_path,
        hmmsearch_binary_path=FLAGS.hmmsearch_binary_path,
        hmmbuild_binary_path=FLAGS.hmmbuild_binary_path,
        small_bfd_database_path=_ovr("small_bfd_database_path", "small_bfd"),
        mgnify_database_path=_ovr("mgnify_database_path", "mgnify"),
        uniprot_cluster_annot_database_path=_ovr("uniprot_database_path", "uniprot"),
        uniref90_database_path=_ovr("uniref90_database_path", "uniref90"),
        ntrna_database_path=_ovr("ntrna_database_path", "ntrna"),
        rfam_database_path=_ovr("rfam_database_path", "rfam"),
        rna_central_database_path=_ovr("rna_central_database_path", "rna_central"),
        pdb_database_path=_ovr("template_mmcif_dir", "template_mmcif_dir"),
        seqres_database_path=_ovr("pdb_seqres_database_path", "pdb_seqres"),
        jackhmmer_n_cpu=8,
        nhmmer_n_cpu=8,
        max_template_date=max_template_date
    )
    return AF3DataPipeline(config)

def _af3_chain_without_templates(chain):
    """Copy a protein chain keeping its MSAs but clearing its templates.

    AlphaFold3's data pipeline dispatches on which of the three fields are set,
    and one branch is exactly what ``--keep_msas`` wants::

        elif has_unpaired_msa and has_paired_msa and not has_templates:
            # Has MSA, but doesn't have templates. Search for templates only.

    The distinction that matters: ``templates=[]`` means "no templates, do not
    search", while ``templates=None`` means "search". A chain with only some of
    the three set is rejected by AF3 outright, so both MSAs must be carried
    over. Non-protein chains have no template search and pass through.
    """
    if folding_input is None or not isinstance(chain, folding_input.ProteinChain):
        return chain
    if chain.unpaired_msa is None or chain.paired_msa is None:
        # Nothing to preserve - let the normal path search everything.
        return chain
    return folding_input.ProteinChain(
        id=chain.id,
        sequence=chain.sequence,
        ptms=chain.ptms,
        residue_ids=chain.residue_ids,
        description=chain.description,
        paired_msa=chain.paired_msa,
        unpaired_msa=chain.unpaired_msa,
        templates=None,
    )


def _af3_input_keeping_msas(existing_path, desc, sequence=None):
    """Build an AF3 Input from existing features that re-searches templates only.

    Returns None when the stored file cannot be reused, so the caller falls back
    to generating features normally.
    """
    try:
        payload = read_maybe_xz(existing_path)
        input_obj = folding_input.Input.from_json(payload)
    except Exception as exc:  # malformed/partial file, or an AF3 schema change
        logging.warning(
            "Cannot reuse existing AF3 features %s for %s (%s); regenerating.",
            existing_path, desc, exc,
        )
        return None

    # Features are matched to the input by description alone, so an edited FASTA
    # that kept its name would otherwise have its MSAs reused for a different
    # protein and be overwritten with features for the wrong sequence. The AF2
    # path refuses that in _existing_monomer_for_update; do the same here.
    if sequence is not None:
        stored = [getattr(chain, "sequence", None) for chain in input_obj.chains]
        if sequence not in stored:
            logging.warning(
                "Existing AF3 features %s hold sequence(s) %s but the input FASTA "
                "has %s; regenerating from scratch instead of keeping their MSAs.",
                existing_path,
                ", ".join(s for s in stored if s) or "none",
                sequence,
            )
            return None

    chains = [_af3_chain_without_templates(chain) for chain in input_obj.chains]
    if not any(
        getattr(chain, "unpaired_msa", None) is not None for chain in chains
    ):
        logging.warning(
            "Existing AF3 features %s carry no MSAs to keep; regenerating.",
            existing_path,
        )
        return None

    return folding_input.Input(
        name=input_obj.name,
        chains=chains,
        rng_seeds=input_obj.rng_seeds,
    )


def create_af3_individual_features():
    """Generate AlphaFold3 features, one .json per chain."""
    validate_data_pipeline_flags()

    # Ensure output directory exists
    os.makedirs(FLAGS.output_dir, exist_ok=True)

    # Resolve every AF3 database flag before collecting provenance.  The AF3
    # pipeline can derive paths lazily, but those derived paths would otherwise
    # be absent from ``flag_values_dict()`` and therefore from the metadata.
    if FLAGS.data_pipeline == "alphafold3":
        create_arguments()
    pipeline = create_pipeline_af3()

    failures = []
    metadata_by_kind = {}
    for seq_idx, (seq, desc) in enumerate(iter_seqs(FLAGS.fasta_paths), 1):
        if FLAGS.seq_index is None or seq_idx == FLAGS.seq_index:
            # Check if output file already exists and skip if requested. Either
            # spelling counts as existing, so a compressed feature set is not
            # silently regenerated (and vice versa).
            plain = Path(FLAGS.output_dir) / f"{desc}_af3_input.json"
            outpath = Path(str(plain) + ".xz") if FLAGS.compress_features else plain
            existing = resolve_af3_input(plain)
            # --keep_msas rewrites existing features, so it takes precedence
            # over --skip_existing: skipping would defeat the point.
            reuse_input = None
            if FLAGS.keep_msas and existing is not None:
                reuse_input = _af3_input_keeping_msas(existing, desc, seq)
            if reuse_input is None and FLAGS.skip_existing and existing is not None:
                logging.info(f"Feature file for {desc} already exists. Skipping...")
                continue

            # Create AlphaFold3 input object with proper chain structure
            try:
                # Generate proper chain ID using AlphaFold3's int_id_to_str_id function
                try:
                    from alphafold3.structure.mmcif import int_id_to_str_id
                    chain_id = int_id_to_str_id(seq_idx)
                except ImportError:
                    # Fallback if mmcif_lib is not available
                    chain_id = chr(ord('A') + (seq_idx - 1) % 26)
                    if seq_idx > 26:
                        # For sequences beyond 26, use AA, BB, etc.
                        chain_id = chain_id + chain_id
                
                chain_kind = get_af3_chain_kind(desc, seq)
                if reuse_input is not None:
                    input_obj = reuse_input
                    logging.info(
                        "Keeping MSAs for %s and re-running template search only.",
                        desc,
                    )
                else:
                    chain = create_af3_chain(seq, desc, chain_id)
                    input_obj = folding_input.Input(
                        name=desc,
                        chains=[chain],
                        rng_seeds=[42]
                    )

                features = pipeline.process(input_obj)
                if hasattr(features, "to_json"):
                    feature_payload = json.loads(features.to_json())
                else:
                    feature_payload = features
                if chain_kind not in metadata_by_kind:
                    metadata_by_kind[chain_kind] = get_af3_feature_metadata(
                        {chain_kind}, skip_msa=FLAGS.skip_msa
                    )
                try:
                    feature_payload = embed_metadata_in_af3_json(
                        feature_payload, metadata_by_kind[chain_kind]
                    )
                except ValueError as exc:
                    # Third-party/test pipelines may return a non-AF3 mapping.
                    # A real AF3 DataPipeline result always contains sequences.
                    logging.warning(
                        "Could not embed feature metadata for %s: %s", desc, exc
                    )
                payload_text = (
                    json.dumps(feature_payload, ensure_ascii=False, indent=2) + "\n"
                )
                if FLAGS.compress_features:
                    with lzma.open(outpath, "wt", encoding="utf-8") as handle:
                        handle.write(payload_text)
                else:
                    outpath.write_text(payload_text, encoding="utf-8")
                    
            except Exception as e:
                logging.error(f"Failed to create AlphaFold3 input object for {desc}: {e}")
                failures.append((desc, str(e)))

    if failures:
        failure_summary = ", ".join(f"{desc} ({error})" for desc, error in failures)
        raise RuntimeError(
            f"Failed to create AlphaFold3 features for {len(failures)} sequence(s): "
            f"{failure_summary}"
        )

# =================== Main Entry Point ===================

def main(argv):
    """Main entry: dispatch to AF2 or AF3, truemultimer or not."""
    del argv

    try:
        validate_data_pipeline_flags()
    except ValueError as exc:
        logging.error(str(exc))
        sys.exit(1)
    
    # Validate required flags based on configuration
    required_flags = ["fasta_paths", "output_dir", "max_template_date"]
    if not FLAGS.use_mmseqs2:
        required_flags.append("data_dir")
    
    # Check if all required flags are provided
    for flag_name in required_flags:
        if not getattr(FLAGS, flag_name):
            logging.error(f"Required flag --{flag_name} is not provided.")
            if flag_name == "data_dir" and FLAGS.use_mmseqs2:
                logging.error("When using --use_mmseqs2, the --data_dir flag is not required as databases are accessed remotely.")
            sys.exit(1)
    
    Path(FLAGS.output_dir).mkdir(parents=True, exist_ok=True)
    if FLAGS.data_pipeline == "alphafold3":
        create_af3_individual_features()
    else:
        check_template_date()
        if FLAGS.path_to_mmt:
            create_individual_features_truemultimer()
        else:
            create_individual_features()

if __name__ == "__main__":
    # Mark basic required flags (data_dir validation is handled in main())
    flags.mark_flags_as_required(["fasta_paths", "output_dir", "max_template_date"])
    app.run(main)
